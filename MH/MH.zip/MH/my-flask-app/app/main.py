from flask import Flask
from .routes import main

# Create the Flask app
app = Flask(__name__)

# Register the blueprint
app.register_blueprint(main)

if __name__ == '__main__':
    app.run(debug=True)